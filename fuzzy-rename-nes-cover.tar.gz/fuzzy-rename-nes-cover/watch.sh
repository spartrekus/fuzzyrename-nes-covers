watch  -e " ls *.nes | head -n 1  ; echo 'List:' ;  ls -ltra target/ | tail " 
