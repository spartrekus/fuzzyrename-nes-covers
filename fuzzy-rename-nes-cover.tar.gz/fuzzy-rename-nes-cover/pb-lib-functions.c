

void linuximgconvert( char *ttfiletarget, char *ttfilesource)
{
    char commandcmdi[PATH_MAX];
    strncpy( commandcmdi , "  " , PATH_MAX );
    strncpy( commandcmdi , " rm file.jpg ; convert  " , PATH_MAX );
    strncat( commandcmdi , " \""  , PATH_MAX - strlen( commandcmdi ) -1 );
    strncat( commandcmdi , ttfilesource , PATH_MAX - strlen( commandcmdi ) -1 );
    strncat( commandcmdi , "\" file.jpg  " , PATH_MAX - strlen( commandcmdi ) -1 );
    system( commandcmdi );


    strncpy( commandcmdi , "  " , PATH_MAX );
    strncpy( commandcmdi , " convert -resize 300\% file.jpg  " , PATH_MAX );
    strncat( commandcmdi , " \""  , PATH_MAX - strlen( commandcmdi ) -1 );
    strncat( commandcmdi , ttfiletarget , PATH_MAX - strlen( commandcmdi ) -1 );
    strncat( commandcmdi , "\" " , PATH_MAX - strlen( commandcmdi ) -1 );

    system( commandcmdi );

    if ( fexist( "file.jpg" ) == 1 )  unlink( "file.jpg" );

    printf( "CMD: %s \n", commandcmdi );
}




void linuxcopy( char *filetarget, char *filesource)
{
    char cmdi[PATH_MAX];
    strncpy( cmdi , " cp -v   " , PATH_MAX );
    strncat( cmdi , " \""  , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , filesource , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , "\" " , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , " \""  , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , filetarget , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , "\" " , PATH_MAX - strlen( cmdi ) -1 );
    printf( "CMD: %s \n", cmdi );
    system( cmdi );
}



void filecopytest( char *filetarget, char *filesource)
{
   FILE *fp1,*fp2;
   char ch;
    fp1 =  fopen( filesource,"rb+");
    fp2 =  fopen( filetarget,"wb+");
    while(1)
    {
       ch = fgetc(fp1);
       if (ch==EOF)
          break;
       else
          putc(ch,fp2);
    }
    fclose(fp1);
    fclose(fp2);
}




void nrunwith( char *mycmd , char *myfile)
{
    char cmdi[PATH_MAX];
    strncpy( cmdi , "   " , PATH_MAX );
    strncat( cmdi , mycmd  , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , " \"" , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , myfile  , PATH_MAX - strlen( cmdi ) -1 );
    strncat( cmdi , "\" " , PATH_MAX - strlen( cmdi ) -1 );
    printf( "CMD: %s \n", cmdi );
    system( cmdi );
}







