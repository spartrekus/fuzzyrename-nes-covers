

#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
//#include <unistd.h>
#include <string.h>
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

//#define PATH_MAX 2500
#include "pb-lib-strings.c" 
#include "pb-lib-functions.c" 






    static int compare_fun( const void *p, const void *q){
      const char *l = p ; 
      const char *r = q ; 
      int cmp; 
      cmp = strcmp( l, r );
      return cmp; 
    }


int fexist(char *a_option){
  char dir1[PATH_MAX]; 
  char *dir2;
  DIR *dip;
  strncpy( dir1 , "",  PATH_MAX  );
  strncpy( dir1 , a_option,  PATH_MAX  );

  struct stat st_buf; 
  int status; 
  int fileordir = 0 ; 

  status = stat ( dir1 , &st_buf);
  if (status != 0) {
    fileordir = 0;
  }

  // this is compatible to check if a file exists
  FILE *fp2check = fopen( dir1  ,"r");
  if( fp2check ) {
  // exists
  fileordir = 1; 
  fclose(fp2check);
  } 

  if (S_ISDIR (st_buf.st_mode)) {
    fileordir = 2; 
  }
return fileordir;
/////////////////////////////
}




int main( int argc, char *argv[])
{
    char myfile[PATH_MAX];
    FILE *fp; 
    FILE *fp1; 
    FILE *fp2; 
    char myline[PATH_MAX];
    char readline[PATH_MAX];
    char myfield1[PATH_MAX];
    char myfield2[PATH_MAX];
    strncpy( myfile , argv[1] , PATH_MAX );


    fp2 = fopen( "listfound.lst" , "wb+");
    fclose( fp2 );

    /// couper les lignes fichiers en deux colonnes
    fp = fopen( myfile , "rb+");
    while(  !feof(fp)   ) {
        fgets( readline , PATH_MAX,  fp );
        if(  !feof(fp)   ) 
        {
            strncpy( myline, string_cut( readline, 6, strlen( string_removelf( readline )) ) , PATH_MAX );
            printf( "%s\n" , myline );
            printf( "Field1: '%s'\n" , string_remove_arrowfield1( myline ) );
            printf( "Field2: '%s'\n" , string_remove_arrowfield2( myline ) );
        }
    }
    fclose( fp );
 



    /// list files into idata array
    char idata[1000][250];
    unsigned filemax = 0;
    unsigned n=0;
    DIR *dirp;
    struct dirent *dp;
    char line[PATH_MAX];
    printf( "----------------- \n" );
    printf( ": LOADING FILES : ... \n" );
    printf( "----------------- \n" );
    n = 1 ; 
    filemax = 0; 
    dirp = opendir( "." );
    while  ((dp = readdir( dirp )) != NULL  &&  
             n < sizeof idata / sizeof idata[ 0 ]) 
    {

        strncpy( line , dp->d_name , 250 );

        if ( strcmp( dp->d_name, "." ) != 0 ) 
        if ( strcmp( dp->d_name, ".." ) != 0 ) 
        {
            strncpy( idata[ n++ ] , dp->d_name , 250 );
            filemax++;
            printf( " -%s\n", dp->d_name );
        } 
    }
    closedir( dirp );


    printf( "----------------- \n" );
    printf( ": SORTING FILES : ... \n" );
    printf( "----------------- \n" );
    if ( n > 1 )
      qsort( idata, n , sizeof idata[0], compare_fun );
    for( n = 1 ; n <= filemax ; n++)
       printf( " -List sorted : %d => %s \n" , n , idata[ n ] );



    ///////////////////
    char filesourcesnap[PATH_MAX];
    char filetargetsnap[PATH_MAX];

    system( " mkdir snaps target " ); 

    printf( "----------------- \n" );
    printf( ": SEARCH PNGs   : ... \n" );
    printf( "----------------- \n" );
    for( n = 1 ; n <= filemax ; n++)
    {
     printf( " -Probing filename : %d => %s \n" , n , idata[ n ] );
     fp = fopen( myfile , "rb+");
     while(  !feof(fp)   ) {
        fgets( readline , PATH_MAX,  fp );
        if(  !feof(fp)   ) 
        {
            strncpy( myline, string_cut( readline, 6, strlen( string_removelf( readline )) ) , PATH_MAX );
            printf( "%s\n" , myline );
            ///////////
            printf( "Field1: '%s'\n" , string_remove_arrowfield1( myline ) );
            printf( "Field2: '%s'\n" , string_remove_arrowfield2( myline ) );
            ///////////
            strncpy( myfield1 , string_remove_arrowfield1( myline ) , PATH_MAX );
            strncpy( myfield2 , string_remove_arrowfield2( myline ) , PATH_MAX );
            
            if ( strstr( idata[ n ] , myfield1  ) != 0 )
            {
              printf( "<--!--> Filename similarity (%s,%s) !! \n", myfield1, idata[ n ]  );

              strncpy( filesourcesnap , "snaps/" , PATH_MAX );
              strncat( filesourcesnap , myfield2  , PATH_MAX - strlen( filesourcesnap ) -1 );
              strncat( filesourcesnap , ".png"  , PATH_MAX - strlen( filesourcesnap ) -1 );

              // fexist copying
              if ( fexist( filesourcesnap ) == 1 )
              {
                strncpy( filetargetsnap , "target/" , PATH_MAX );
                strncat( filetargetsnap , string_replace2( idata[ n ] , ".nes" , ".png" ) , PATH_MAX - strlen( filetargetsnap ) -1 );
                linuxcopy( filetargetsnap, filesourcesnap );
              }
              
              // report copying to file
              fp2 = fopen( "listfound.lst" , "ab+");
                fputs( idata[ n ] ,  fp2);
                fputs( " ; ",  fp2);
                fputs( myfield1 ,  fp2);
                if ( fexist( filesourcesnap ) == 1 ) 
                  fputs( "; file snap copied;" ,  fp2);
                  else
                  fputs( "; file snap not found;" ,  fp2);
                fputs( "\n",  fp2);
              fclose( fp2 );
            }
        }
     }
     fclose( fp );
    } 


    return 0;
}


