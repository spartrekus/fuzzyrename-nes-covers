
char *string_cut( char *aoption , int cutstart  , int lengthexttmp ){
  char buffer[PATH_MAX];
  char charo[PATH_MAX];

  // to make sure that it takes not above the cut
  int lengthext=0;
  lengthext = lengthexttmp;
  if ( lengthexttmp > strlen( aoption) ) 
     lengthext = strlen( aoption );

  int i, chd, cx , j ; 
  strncpy( buffer, "" , PATH_MAX);

  if ( lengthext <= strlen( aoption) )
  {
    for ( i= cutstart -1 ;  ( i <= lengthext -1 )  ; i++ ) 
    {
      j = snprintf( charo, 5 , "%c", aoption[i]);
      strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
    }
  }
  else
    j = snprintf( buffer, PATH_MAX , "%s", aoption);


  size_t len = strlen(buffer);
  char *r = malloc(len+1);
  return r ? memcpy(r, buffer, len+1) : NULL;
}





int strfindpos( char *linetmp, char thechar ){
   int i , j , k ;
   char line[PATH_MAX];
   k = 0;

			  // rem last \n
			  // start
			  strncpy( line, "" , PATH_MAX );
			  for( i = 0 ; ( i <= strlen( linetmp ) ); i++ )
			  {
			      if ( linetmp[ i ] == thechar ) 
			        k = i ; 
			  }
			     //if ( linetmp[i] != '\n' )
			     //if ( linetmp[i] != '\r' )
			//	line[i]=linetmp[i];
			   // end

   return k;
}






char *string_remove_arrowfield1b( char *linetmp ){
   int arrowpos = 0;
   int i , j , k ;
   char line[PATH_MAX];
   arrowpos = strfindpos( linetmp , '>' );
   printf( "arrowpos=%d\n" , arrowpos );
   strncpy( line, string_cut( linetmp , 1, arrowpos -2 ), PATH_MAX );
   size_t siz = sizeof line ; 
   char *r = malloc( sizeof line );
   return r ? memcpy(r, line, siz ) : NULL;
}


char *string_remove_arrowfield2b( char *linetmp ){
   int arrowpos = 0;
   int i , j , k ;
   char line[PATH_MAX];
   arrowpos = strfindpos( linetmp , '>' );
   printf( "arrowpos=%d\n" , arrowpos );
   strncpy( line, string_cut( linetmp , arrowpos +3, strlen( linetmp ) ), PATH_MAX );
   size_t siz = sizeof line ; 
   char *r = malloc( sizeof line );
   return r ? memcpy(r, line, siz ) : NULL;

}



char *string_remove_arrowfield2( char *linetmp ){
      int i , j , k ;
      char line[PATH_MAX];
      int equalfound = 0 ; 

			  // rem last \n
			  // start
                          j=0;
			  strncpy( line, "" , PATH_MAX );
			  for( i = 0 ; ( i <= strlen( linetmp ) ); i++ )
                          {
                             if ( equalfound == 1 )
				line[j++]=linetmp[i];

			     if ( ( linetmp[i-3] == ' ' )
			     && ( linetmp[i-2] == '=' )
			     && ( linetmp[i-1] == '>' ) 
			     && ( linetmp[i] == ' ' ) )
                                equalfound = 1;

			     // end

                          }
   size_t siz = sizeof line ; 
   char *r = malloc( sizeof line );
   return r ? memcpy(r, line, siz ) : NULL;
}







char *string_remove_arrowfield1( char *linetmp ){
      int i , j , k ;
      char line[PATH_MAX];
      int equalfound = 0 ; 

			  // rem last \n
			  // start
			  strncpy( line, "" , PATH_MAX );
			  for( i = 0 ; ( i <= strlen( linetmp ) ); i++ )
                          {
			     if ( ( linetmp[i] != ' ' )
			     || ( linetmp[i+1] != '=' )
			     || ( linetmp[i+2] != '>' ) )
				line[i]=linetmp[i];
			   // end

	          	     if ( linetmp[i] == ' ' )
	          	     if ( linetmp[i+1] == '=' )
			     if ( linetmp[i+2] == '>' )
                                break;
                          }
   size_t siz = sizeof line ; 
   char *r = malloc( sizeof line );
   return r ? memcpy(r, line, siz ) : NULL;
}






char * string_removelf( char *linetmp ){
      int i , j , k ;
      char line[PATH_MAX];

			  // rem last \n
			  // start
			  strncpy( line, "" , PATH_MAX );
			  for( i = 0 ; ( i <= strlen( linetmp ) ); i++ )
			     if ( linetmp[i] != '\n' )
			     if ( linetmp[i] != '\r' )
				line[i]=linetmp[i];
			   // end

   size_t siz = sizeof line ; 
   char *r = malloc( sizeof line );
   return r ? memcpy(r, line, siz ) : NULL;
}




// *20150702-224902* - extended to long
char * string_awk_cut( char aoption[PATH_MAX] , char cutstring  , int itemnb ){
  char buffer[PATH_MAX];
  char charo[PATH_MAX];
  int i, chd, cx , j ; 
  int cutstringfound =1;
  strncpy( buffer, "" , PATH_MAX);

  {
    // modded  !!! please check it if it really works
    // 20130701-145851
    for ( i=0 ;  ( i <= strlen( aoption ) )  ; i++ ) 
    {
   // strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
   
  if ( ( aoption[i] != '\n' ) && ( aoption[i] != '\r' ) ) {
   if ( aoption[i] == cutstring ){
      cutstringfound++;
   }

   if ( (  itemnb == cutstringfound ) 
   && ( aoption[i] != cutstring ) ){
      j = snprintf( charo, 5 , "%c", aoption[i]);
      strncat( buffer , charo , PATH_MAX - strlen(buffer) - 1);
   }

    }
  }
  }

  size_t len = strlen(buffer);
  char *r = malloc(len+1);
  return r ? memcpy(r, buffer, len+1) : NULL;
}




// tested and ok
char * string_replace2( char  *original, char  *pattern, char  *replacement) {
  size_t const replen = strlen(replacement);
  size_t const patlen = strlen(pattern);
  size_t const orilen = strlen(original);

  size_t patcnt = 0;
  const char * oriptr;
  const char * patloc;

  // find how many times the pattern occurs in the original string
  for (oriptr = original; patloc = strstr(oriptr, pattern); oriptr = patloc + patlen)
  {
    patcnt++;
  }

  {
    // allocate memory for the new string
    size_t const retlen = orilen + patcnt * (replen - patlen);
    char * const returned = (char *) malloc( sizeof(char) * (retlen + 1) );

    if (returned != NULL)
    {
      // copy the original string, 
      // replacing all the instances of the pattern
      char * retptr = returned;
      for (oriptr = original; patloc = strstr(oriptr, pattern); oriptr = patloc + patlen)
      {
        size_t const skplen = patloc - oriptr;
        // copy the section until the occurence of the pattern
        strncpy(retptr, oriptr, skplen);
        retptr += skplen;
        // copy the replacement 
        strncpy(retptr, replacement, replen);
        retptr += replen;
      }
      // copy the rest of the string.
      strcpy(retptr, oriptr);
    }
    return returned;
  }
}



